<!doctype html>
<!--[if lt IE 7]>		<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>			<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>			<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->	<html class="no-js" lang="zxx"> <!--<![endif]-->
 
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Welcome to  Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</title>
	<meta name="description" content=" Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik
 It gives me immense pleasure, in welcoming you all to Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik. It is an institute where discipline and punctuality with conducive environment will provide quality education development in frontier areas of Engineering and Technology. We, the faculty, staff and administration at PVG Institute will work for producing technologically superior and ethically strong engineers for the country and the world, with a purpose to serve the society & mankind. Withstrong team work we would achieve technological excellence in a highly competitive environment around us.
">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="apple-touch-icon" href="apple-touch-icon.png">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/prettyPhoto.css">
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/owl.theme.default.css">
	<link rel="stylesheet" href="css/transitions.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/color.css">
	<link rel="stylesheet" href="css/responsive.css">
	
	
<link rel="stylesheet" href="main.css">


	<script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <link rel="apple-touch-icon" sizes="57x57" href="images/fa/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/fa/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/fa/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/fa/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/fa/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/fa/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/fa/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/fa/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/fa/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="images/fa/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="images/fa/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="images/fa/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="images/fa/favicon-16x16.png">
<link rel="manifest" href="images/fa/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="images/fa/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
</head>
<body class="tg-home tg-homeone">
	<!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
	<!--************************************
			Wrapper Start
	*************************************-->
	<div id="tg-wrapper" class="tg-wrapper">
		<!--************************************
				Header Start
		*************************************-->
			<!--************************************
				Header START
		*************************************-->
<header id="tg-header" class="tg-header tg-haslayout">
			<div class="tg-topbar">
				<div class="tg-leftbox">
					<span id="tg-datebox" class="tg-datebox" style="color:#FFF;"></span>
					<span class="tg-rtltextbox" style="color:#FFF;">  You are at: Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</span>
				</div>
				<div class="tg-rightbox">
					<span class="tg-tollfree"><a href="tel:02532534291" title="Enquiry @: 0253 2534291" style="color:#FFF;">Enquiry @: 0253 2534291</a></span>
					 
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div class="tg-logoandnoticeboard">
							<strong class="tg-logo"><a href="index.php" title="Pune Vidyarthi Griha's Dr. Kakasaheb Deodhar English School, Nashik"><img src="images/kdeslogo.png" alt=" Pune Vidyarthi Griha's Dr. Kakasaheb Deodhar English School, Nashik" title=" Pune Vidyarthi Griha's Dr. Kakasaheb Deodhar English School, Nashik"></a></strong>
							<div class="tg-noticeboard hidden-xs">
								<div class="tg-textbox">
									<span><marquee direction="left" onMouseOver="stop()" onMouseOut="start()" scrollamount="3.5"><a href="http://www.pvgkdesnashik.in/index.php?tcf=admission" title="Latest News &amp; Updates">Admissions Open for Pre Primary School For Year 2024-2025</a></marquee></span>
								</div>
								<figure><img src="images/img-01.jpg" alt="PVG Latest News &amp; Updates"></figure>
							</div>
						</div>
						<div class="tg-navigationarea">
							<nav id="tg-nav" class="tg-nav">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#tg-navigation" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div id="tg-navigation" class="collapse navbar-collapse tg-navigation">
									<ul>
										<li class="-menu-item">
											<a href="./kdespreprimary" title="PVG's Dr. Kakasaheb Deodhar English School, Nashik | Pre Primary Section" target="_blank">PVG`s Kinder Garten</a>
											
										</li>
                                        
                                        <li class="-menu-item">
											<a href="./kdesprimary" title="PVG's Dr. Kakasaheb Deodhar English School, Nashik | Primary Section" target="_blank">Primary School</a>
											
										</li>
                                         <li class="-menu-item">
											<a href="./kdessecondary" title="PVG's Dr. Kakasaheb Deodhar English School, Nashik | Primary Section" target="_blank">Secondary &amp; Higher Secondary School</a>
											
										</li>
										 
                                       <li ><a href="index.php?tcf=admission" data-new="new" title="Admission 2024-2025">Admission 2024-2025</a> </li>
										 
									</ul>
								</div>
							</nav>
							<div class="tg-searchbox">
								<a id="tg-btnsearch" class="tg-btnsearch" href="#" title="Search"><i class="icon-magnifier"></i></a>
								<form class="tg-formtheme tg-formsearch">
									<fieldset><input type="search" name="search" class="form-control" placeholder="Start Your Search Here"></fieldset>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!--************************************
				Header End
		*************************************-->		<!--************************************
				Home Slider Start
		*************************************-->
		<div class="clearfix"></div>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="tg-homebannervtwo">
                       
                    
						<div id="tg-addmissionslider" class="tg-homeslider owl-carousel tg-btnround tg-haslayout" style="width:100%">
  
    
    <figure class="item"><img src="sliderimage/pvgkdes-preprimary-31.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
        <figcaption class="tg-slidercontent">
            <div class="tg-slidercontentbox">
                <div class="tg-titledescription">
                   <h1 style="font-size:15px">Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</h1>
                </div>
            </div>
        </figcaption>
    </figure>
    
    <figure class="item"><img src="sliderimage/pvgkdes-preprimary-6.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDES">
        <figcaption class="tg-slidercontent">
            <div class="tg-slidercontentbox">
                <div class="tg-titledescription">
                   <h1 style="font-size:15px">Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</h1>
                </div>
            </div>
        </figcaption>
    </figure>
    
      <figure class="item"><img src="sliderimage/pvgkdes-secondary-school-40.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDES">
       <figcaption class="tg-slidercontent">
            <div class="tg-slidercontentbox">
                <div class="tg-titledescription">
                   <h1 style="font-size:15px">Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</h1>
                </div>
            </div>
        </figcaption>
    </figure>
    <figure class="item"><img src="sliderimage/pvgkdes2.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDES">
       <figcaption class="tg-slidercontent">
            <div class="tg-slidercontentbox">
                <div class="tg-titledescription">
                   <h1 style="font-size:15px">Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</h1>
                </div>
            </div>
        </figcaption>
    </figure>
     <figure class="item"><img src="sliderimage/pvgkdes-preprimary-27.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDES">
       <figcaption class="tg-slidercontent">
            <div class="tg-slidercontentbox">
                <div class="tg-titledescription">
                   <h1 style="font-size:15px">Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</h1>
                </div>
            </div>
        </figcaption>
    </figure>
     <figure class="item"><img src="sliderimage/pvgkdes-secondary-school-28.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDES">
       <figcaption class="tg-slidercontent">
            <div class="tg-slidercontentbox">
                <div class="tg-titledescription">
                   <h1 style="font-size:15px">Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik</h1>
                </div>
            </div>
        </figcaption>
    </figure>
    
   
 
</div>                         
					</div>
                    
                    
				 
 				</div>
			</div>
		</div>
		<!--************************************
				Home Slider End
		*************************************-->
		<!--************************************
				Main Start
		*************************************-->
		
        
        
        <!-- Added By SMS -->    
<!--
<div class="jquery-script-ads"> 


<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>


</div>

<div id="boxes">
  <div style="top: 199.5px; left: 551.5px; display: none;" id="dialog" class="window"> 
    <div id="lorem">
      <p align="center"><a href="http://www.pvgkdesnashik.in/index.php?tcf=admission" target="_blank"> <img src="images/admission_pop_up.jpg" width="350px" title="CLick here For New Admission."    ></a></p>
    </div>
    <div id="popupfoot"> <a href="#" class="close agree">Close</a>   
    <a class="agree"style="color:red;" href="http://www.pvgkdesnashik.in/index.php?tcf=admission">Go to Admission Enquiry</a> </div>
  </div>
  <div style="width: 148px; font-size: 3pt; color:none; height: 62px; display: none; opacity: 0.8;" id="mask"></div>
</div>
-->



            



<!-- Added By SMS -->  

<div class="container">
				<div class="row">
					<div id="tg-twocolumns" class="tg-twocolumns">
                    <div class="tg-widgettitle">
                            		<h3 style="font-size:20px" ><i class="fa fa-camera" aria-hidden="true"></i> About Us</h3>
                            </div>
                    
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div id="tg-content" class="tg-content">
								<section class="tg-sectionspace tg-haslayout">
									<div class="tg-shortcode tg-welcomeandgreeting">
										<figure><img src="images/pre-primary-school.jpg" alt="image description" width="500" /></figure>
										<div class="tg-shortcodetextbox">
											<h2>Pre Primary School</h2>
											<div class="tg-description" style="color:#000;">
												<ul align="justify">
                                                	<li>Language development through phonetics</li>
                                                    <li>Five senses development activities</li>
                                                    <li>Theme based education</li>
                                                    <li>Indoor & Outdoor Games</li>
                                                    <li>Art &amp; Craft</li>
                                                    <li>Field Visit</li>
                                                    <li>Individual attention</li>
                                                    <li>Exposure to Technology</li>
                                                    <li>Value based education</li>
                                                    <li>Nature Study</li>
                                                    <li>Bus Facility</li>
                                                    <li>Upgrade winning attitude</li>
                                                
                                                </ul>
<a href="./kdespreprimary/"><button type="submit" class="tg-btn">Go to Website</button></a>

											</div>
										</div>
									</div>
								</section>
                                
                                <section class="tg-sectionspace tg-haslayout">
									<div class="tg-shortcode tg-welcomeandgreeting">
										<figure><img src="images/kdes-primary-school.jpg" alt="image description" width="500" /></figure>
										<div class="tg-shortcodetextbox">
											<h2>Primary School</h2>
											<div class="tg-description" style="color:#000;">
												 
												<ul align="justify">
                                                	<li>A unique newe building with big and airy classrooms Digital board in every classroom.</li>
                                                    <li>The only having an impact of geart Indian Culture.</li>
                                                    <li>Playground of minimum 5 acres.</li>
                                                    <li>A geart surrounding for the enhancement and development of students.</li>
                                                    <li>Entire campus and all the class rooms under the CCTV surveillance</li>
                                                    <li>Teacher's enrichment programmes</li>
                                                     <li>Facility of evening games.</li>
                                                
                                                </ul>
<a href="./kdesprimary"><button type="submit" class="tg-btn">Go to Website</button></a>
											</div>
										</div>
									</div>
								</section>
                                
                                
                                <section class="tg-sectionspace tg-haslayout">
									<div class="tg-shortcode tg-welcomeandgreeting">
										<figure><img src="images/kdes-secondary-school.jpg" alt="image description" width="500" /></figure>
										<div class="tg-shortcodetextbox">
											<h2>Secondary School</h2>
											<div class="tg-description" style="color:#000;">
												<p align="justify">School is situated at prime location in Nashik city and spread well over 20 acres of area combination of huge playground, beautiful campus and modern facilities which make it one of the most unique in Nashik city </p>
												<ul align="justify">
                                                	<li>Digital class rooms</li>
                                                    <li>Well-equipped science and I.T. laboratory</li>
                                                    <li>Facility of evening games.</li>
                                                    <li>Well educated and trained staff.</li>
                                                    <li>Entire campus and all the classrooms under the CCTV surveillance</li>
                                                    <li>Well-resourced digital library.</li>
                                                
                                                </ul>
<a href="./kdessecondary"><button type="submit" class="tg-btn">Go to Website</button></a>

											</div>
										</div>
									</div>
								</section>
                                
                                <section class="tg-sectionspace tg-haslayout">
									<div class="tg-shortcode tg-welcomeandgreeting">
										<figure><img src="images/kdes-higher-secondary-school.jpg" alt="image description" width="500" /></figure>
										<div class="tg-shortcodetextbox">
											<h2>Higher Secondary School</h2>
											<div class="tg-description" style="color:#000;">
												<p align="justify">School is situated at prime location in Nashik city and spread well over 20 acres of area combination of huge playground, beautiful campus and modern facilities which make it one of the most unique in Nashik city </p>
												<ul align="justify">
                                                	<li>Digital class rooms</li>
                                                    <li>Well-equipped science and I.T. laboratory</li>
                                                    <li>Facility of evening games.</li>
                                                    <li>Well educated and trained staff.</li>
                                                    <li>Entire campus and all the classrooms under the CCTV surveillance</li>
                                                    <li>Well-resourced digital library.</li>
                                                
                                                </ul>
<a href="./kdessecondary"><button type="submit" class="tg-btn">Go to Website</button></a>
											</div>
										</div>
									</div>
								</section>
                                
                                 
                                 
                                 
							</div>
						</div>
						 
						 
                    </div>
				</div>
			</div>



<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div id="tg-content" class="tg-content">
							<div class="tg-widgettitle">
                            		<h3 style="font-size:20px" ><i class="fa fa-camera" aria-hidden="true"></i> Our Photogallery</h3>
                            </div>
							<div class="tg-gallerymasnory">
								 
                                   <!---////////////////////-----College------//////////////---------->
								<div id="tg-galleryfilterable" class="tg-galleryfilterable">
									<div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school4.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school4.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/pvgkdes-preprimary-27.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/pvgkdes-preprimary-27.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/kdes_2.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/kdes_2.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/IMG-20191202-WA0003.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/IMG-20191202-WA0003.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                   
                                       <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/pvgcoen_4.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/pvgcoen_4.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    
                                     <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school1.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school1.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    
                                        <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school10.JPG" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school10.JPG" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                        <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school12.JPG" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school12.JPG" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                        <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school1.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school1.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                      <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school6.JPG" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school6.JPG" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                      <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school7.JPG" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school7.JPG" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    
                                      <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/school7.JPG" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/school7.JPG" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    
                                      <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/kdes_lab2.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/kdes_lab2.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    
                                      <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/kdes_12.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/kdes_12.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    
                                      <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/kdes_lab4.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/kdes_lab4.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                     <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/pvgkdes-secondary-school-16.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/pvgkdes-secondary-school-16.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                     <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/bail-pola-ganpati-3.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/bail-pola-ganpati-3.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                     <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/pvgkdes-preprimary-11.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/pvgkdes-preprimary-11.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                    <div class="tg-masonrygrid">
										<figure>
											<img src="images/gallery/pvgkdes-preprimary-26.jpg" alt="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk" title="Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik | KDESk">
											<a class="tg-btnviewimg" href="images/gallery/pvgkdes-preprimary-26.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-magnifier"></i></a>
										</figure>
									</div>
                                      
                                    
								</div>
							</div>
						</div>
					</div>
				</div>
                </div>
                
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script> 
<script src="../main.js"></script>
                      
        
     
        
		<!--************************************
				Main End
		*************************************-->
		<!--************************************
				Footer Start
		*************************************-->
		<footer id="tg-footer" class="tg-footer tg-haslayout">
			<div class="tg-signupbox">
				<div class="container">
					 
					 
				</div>
			</div>
			<div class="tg-footermiddlebar">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
							<div class="tg-widget tg-widgetcompanyinfo">
								<div class="tg-widgetcontent">
									<strong class="tg-logo"><a href="index.php?tcf=home" title="Pune Vidyarthi Griha’s College of Engineering, Nashik"><img src="images/logo.png" alt=" Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik" title=" Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik"></a></strong>
									<div class="tg-description">
										<p align="justify">Pune Vidhyarthi Griha has started Dr. Kakasaheb Deodhar English School in Mhasrul on June 16th, 2001. The purpose of thee school is not only to impart education but also to develop intellectual. moral, emotional, physical and asthetic faculties in students. </p>
									</div>
								 
								</div>
							</div>
						</div>
						 
						<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
							<div class="tg-widget tg-widgetcompanyinfo">
                            	<div class="tg-widgettitle">
									<h3>Reach us</h3>
								</div>
								<div class="tg-widgetcontent">
									 
										 
								 
									<ul class="tg-infolist">
										<li>
											<i class="icon-location"></i>
											Pune Vidyarthi Griha`s Dr. Kakasaheb Deodhar English School, Nashik <br>PVG Campus, 206, Dindori road,<br>Behind Reliance Petrol Pump, Near MERI, Mhasarul,<br>Nashik - 422004.<br>Maharashtra. INDIA.
										</li>
										<li>
											<i class="icon-phone-handset"></i>
											<span><a href="tel:+91253 2534291" title="Call us for Enquiry">0253 2534291</a></span>
                                             
										</li>
										 
										<li>
											
												<i class="icon-envelope"></i>
												<span><a href="/cdn-cgi/l/email-protection#58282e3f282a31363b312839342b3d3b37363c392a21183f35393134763b3735" title="Email us pvgprincipalsecondary@gmail.com"><span class="__cf_email__" data-cfemail="b5c5c3d2c5c7dcdbd6dcc5d4d9c6d0d6dadbd1d4c7ccf5d2d8d4dcd99bd6dad8">[email&#160;protected]</span></a></span>
											
										</li>
                                        <li>
											
												<i class="icon-globe"></i>
												<span><a href="https://pvgkdesnashik.in/" title="www.pvgkdesnashik.in" target="_blank">www.pvgkdesnashik.in</a></span>
											
										</li>
									</ul>
									<ul class="tg-socialicons">
										<li class="tg-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li class="tg-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li class="tg-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="tg-googleplus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
										 
									</ul>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
							<div class="tg-widget tg-widgetflickrgallery">
								 
								<div class="tg-widgetcontent">
									 
                                   <iframe src="
https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d119947.61513497283!2d73.73112095881504!3d20.03523372097103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddea318c6cf9af%3A0x703917efb29fcbe8!2sDr.+Kakasaheb+Deodhar+English+School%2C+Nashik!5e0!3m2!1sen!2sin!4v1505913668250	" width="500" height="250" frameborder="0" style="border:0;margin-top:15px" allowfullscreen>
                       </iframe>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tg-footerbar" >
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"  style="color:#FFF;">
							
                            
							<span class="tg-copyright">Powered by : <a href="http://technocratsforum.in" target="_blank" title="Website Powered by : TECHNOCRATS FORUM, Nashik"  style="color:#FFF;">TECHNOCRATS FORUM, Nashik</a></span>
                            
                           
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--************************************
				Footer End
		*************************************-->
	</div>
	<!--************************************
			Wrapper End
	*************************************-->
	<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/vendor/jquery-library.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/mapclustering/data.json"></script>
	<script src="https://maps.google.com/maps/api/js?key=AIzaSyCR-KEWAVCn52mSdeVeTqZjtqbmVJyfSus&amp;language=en"></script>
	<script src="js/mapclustering/markerclusterer.min.js"></script>
	<script src="js/mapclustering/infobox.js"></script>
	<script src="js/mapclustering/map.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/isotope.pkgd.js"></script>
	<script src="js/prettyPhoto.js"></script>
	<script src="js/countdown.js"></script>
	<script src="js/collapse.js"></script>
	<script src="js/moment.js"></script>
	<script src="js/gmap3.js"></script>
	<script src="js/main.js"></script>
	
	
    
    
</body>

 
</html>